<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aplikasi Diskon</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #FBF5DD;
        }

        form{
            margin-top: 20px;
            padding: 15px;
            background-color: #A6CDC6;
            border-radius: 8px;
        }

        .container {
            padding-top: 50px;
        }

        h2 {
            color:#fff;
            margin-bottom: 20px;
            text-align:center;
        }

        .form-control {
            border-radius: 5px;
            padding: 15px;
            font-size: 16px;
        }

        .btn {
            font-size: 16px;
            padding: 12px;
            border-radius: 5px;
        }

        #hitung {
            background-color: #DDA853;
            border-color: #fff;
            color:#fff;
        }

        #hitung {
            background-color: #DDA853;
            border-color: #fff;
            color:#fff;
        }

        #reset {
            background-color: #16404D;
            border-color: #fff;
            color:#fff;
        }

        #reset {
            background-color: #16404D;
            border-color: #fff;
            color:#fff;
        }

        .border {
            margin-top: 20px;
            padding: 15px;
            background-color: #A6CDC6;
            border-radius: 8px;
        }

        .p-2 {
            padding: 10px;
        }

        .text-center {
            margin-top: 30px;
            font-size: 14px;
            color: #555;
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h2>Aplikasi Perhitungan Diskon</h2>
                <form method="post" class="border rounded p-2">
                    <div class="mb-3">
                        <label class="form-label">Harga Barang (Rp.)</label>
                        <input type="number" name="harga" class="form-control" min="0" step="0.01" placeholder="Masukan Harga barang" autocomplete="off">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Diskon (%)</label>
                        <input type="text" name="diskon" maxlength="3" class="form-control" min="0" step="0.01" placeholder="Masukan Diskon" onkeypress="return event.charCode >= 48 && event.charCode <= 57">
                    </div>
                    <button type="submit" id="hitung" class="btn w-100 mt-2" name="hitung">Hitung</button>
                    <button type="reset" id="reset" class="btn w-100 mt-2" onclick="hapusDiv()">Reset</button>

                    <?php
                        if(isset($_POST['hitung'])){
                            $harga = $_POST['harga'];
                            $diskon = $_POST['diskon'];

                            if($harga < 0){
                                echo "<script>alert('Masukan harga dengan benar')</script>";
                            } elseif($diskon < 0 || $diskon > 100){
                                echo "<script>alert('Masukan diskon yang valid')</script>";
                            } else {
                                $nilai_diskon = $harga * ($diskon / 100);
                                $total_harga = $harga - $nilai_diskon;
                    ?>

                    <div class="border bg-light p-2" name="hilangDiv">
                        <p>Harga : Rp. <b><?php echo number_format($harga, 2, ',', '.') ?></b></p>
                        <p>Diskon <?php echo $diskon; ?>% : Rp. <b><?php echo number_format($nilai_diskon, 2, ',', '.') ?></b></p>
                        <p>Harga setelah diskon : Rp. <b><?php echo number_format($total_harga, 2, ',', '.') ?></b></p>
                    </div>

                    <?php
                            }
                        }
                    ?>

                </form>
            </div>
        </div>
    </div>

    <p class="text-center">&copy;Tian|UKK 2025</p>

    <script>
        function hapusDiv() {
            var hps = document.getElementsByName("hilangDiv")[0];
            if (hps) {
                hps.remove();
            }
        }
    </script>

</body>
</html>